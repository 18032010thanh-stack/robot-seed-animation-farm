"""Real Vietnamese narration for Kreelux-style sample, based on exact V2 lines.
Uses edge-tts word-boundary timing, ffmpeg decoding and source-word alignment.
No stock narration, songs, V1 assets or artificial placeholder media.
"""
import asyncio
import difflib
import json
import math
import re
import subprocess
import wave
from pathlib import Path

import numpy as np
import edge_tts

ROOT=Path(__file__).resolve().parents[1]
STORY=json.loads((ROOT/'story'/'v2_ep03_kreelux_short.json').read_text(encoding='utf8'))
OUT=ROOT/'output'
SR=24000
FPS=STORY['fps']
DURATION=STORY['frames']/FPS

def nominals():
    a=[];t=0.0
    for s in STORY['shots']:
        a.append(t);t+=float(s['dur'])
    return a

def norm(word):
    return re.sub(r'^\W+|\W+$','',word.lower(),flags=re.UNICODE)

def align_words(script,events,t0,tempo,limit):
    source=script.split()
    values=[str(e['text']).strip() for e in events]
    if not values: raise RuntimeError('Edge TTS returned no word timestamps for '+script)
    # Preserve the V2 story spelling, not ASR guesses: use difflib alignment.
    normalized=[norm(w) for w in source]
    mapped=[norm(w) for w in values]
    matches=difflib.SequenceMatcher(None,normalized,mapped,autojunk=False).get_opcodes()
    times=[None]*len(source)
    for tag,i,j,k,l in matches:
        if tag=='equal':
            for idx,e in zip(range(i,j),events[k:l]):
                t=t0+e['offset']/10000000/tempo
                d=e['duration']/10000000/tempo
                times[idx]=[t,min(t+d,limit)]
        else:
            # Only interpolate missing word boundaries; keep original text.
            st=t0+(events[max(k-1,0)]['offset']/10000000/tempo if k else 0)
            en=t0+((events[min(l,len(events))-1]['offset']+events[min(l,len(events))-1]['duration'])/10000000/tempo if l else 0)
            if en<=st: en=st+max(.08,(limit-st)/max(len(source)-i,1))*(j-i)
            for offset,idx in enumerate(range(i,j)):
                x=st+(en-st)*offset/max(1,j-i)
                y=st+(en-st)*(offset+1)/max(1,j-i)
                times[idx]=[x,min(y,limit)]
    if any(x is None for x in times):raise RuntimeError('Word matching logic failed')
    result=[]
    for w,(a,b) in zip(source,times):
        if b<=a: b=min(limit,a+.055)
        if a>=limit:raise RuntimeError('Narration word past scene slot: '+w)
        result.append({'word':w,'start':round(a,4),'end':round(b,4),'script_exact':True})
    return result

def run(args,stdin=None):
    p=subprocess.run(args,input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    if p.returncode:raise RuntimeError('FFmpeg: '+p.stderr.decode('utf8','replace')[-1800:])
    return p.stdout

async def synth_line(index,text):
    mp3=OUT/'voice_segments'/f'line_{index+1:02}.mp3'
    events=[]
    audio=bytearray()
    communicator=edge_tts.Communicate(text,voice=STORY['voice'],rate='+18%')
    async for result in communicator.stream():
        if result['type']=='audio':audio.extend(result['data'])
        elif result['type']=='WordBoundary':events.append(result)
    if len(audio)<2000 or not events:raise RuntimeError('Online voice/word timings unavailable for shot '+str(index+1))
    mp3.write_bytes(audio)
    return mp3,events

async def main():
    OUT.mkdir(exist_ok=True)
    (OUT/'voice_segments').mkdir(exist_ok=True)
    starts=nominals()
    spoken=[i for i,s in enumerate(STORY['shots']) if s['line'].strip()]
    mix=np.zeros(int(round(DURATION*SR)),dtype=np.float32)
    all_words=[]
    log=[]
    for pos,i in enumerate(spoken):
        text=STORY['shots'][i]['line'].strip()
        next_i=spoken[pos+1] if pos+1<len(spoken) else len(STORY['shots'])
        begin=round(starts[i]*FPS)/FPS
        slot_end=round(starts[next_i]*FPS)/FPS if next_i<len(starts) else DURATION
        available=slot_end-begin-.12
        if available<.4:raise RuntimeError('Voice slot too short for '+text)
        mp3,events=await synth_line(i,text)
        raw=run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(mp3),'-ar',str(SR),'-ac','1','-f','f32le','pipe:1'])
        x=np.frombuffer(raw,dtype='<f4').copy()
        length=len(x)/SR
        tempo=max(1.0,length/available)
        if tempo>1.65:
            raise RuntimeError(f'Voice for shot {i+1} needs unacceptable speedup x{tempo:.2f} to preserve exact V2 cuts')
        if tempo>1.01:
            data=run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(mp3),'-af',f'atempo={tempo:.4f}', '-ar',str(SR),'-ac','1','-f','f32le','pipe:1'])
            x=np.frombuffer(data,dtype='<f4').copy()
        start_index=int(round((begin+.04)*SR))
        lim=min(len(x),len(mix)-start_index,int(available*SR))
        if lim<=0:raise RuntimeError('Narration does not fit the story timeline')
        if lim<len(x)*.97:raise RuntimeError('Audio would have been noticeably truncated')
        x=x[:lim]
        fade=min(len(x)//5,round(SR*.025))
        if fade:
            x[:fade]*=np.linspace(0,1,fade)
            x[-fade:]*=np.linspace(1,0,fade)
        mix[start_index:start_index+len(x)]+=x
        all_words.extend(align_words(text,events,begin+.04,tempo,min(slot_end-.015,DURATION)))
        log.append({'shot':i+1,'text':text,'tts_audio_original_seconds':round(length,3),'tempo':round(tempo,3),'slot_seconds':round(slot_end-begin,3),'tts_words':len(events)})
    peak=float(np.max(np.abs(mix)))
    if peak>.87:mix*=.87/peak
    wav=OUT/'narration_vi.wav'
    with wave.open(str(wav),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR)
        w.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
    (OUT/'narration_words.json').write_text(json.dumps(all_words,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    (OUT/'voice_alignment_report.json').write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('VOICE READY',len(all_words),'exact V2 words, duration',DURATION,'s; peak',round(peak,3),flush=True)

if __name__=='__main__':asyncio.run(main())
