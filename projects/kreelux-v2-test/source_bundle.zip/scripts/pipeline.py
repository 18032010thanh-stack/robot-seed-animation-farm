#!/usr/bin/env python3
"""GitHub Actions Blender video production; fully reproducible from original V2 words
and NEW Kreelux style only. Does NOT load or depend upon V1 files.
"""
import argparse
import ast
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'
STORY=json.loads((ROOT/'story'/'v2_ep03_kreelux_short.json').read_text(encoding='utf8'))
FPS=STORY['fps']
TOTAL=STORY['frames']
CHUNKS=3
INTERVALS=[]
cur=0.0
for s in STORY['shots']:
    start=round(cur*FPS)+1
    cur+=float(s['dur'])
    INTERVALS.append((start,round(cur*FPS)))
assert INTERVALS[-1][1]==TOTAL


def clip_range(chunk):
    if not 1<=chunk<=CHUNKS:raise ValueError('chunk must be 1-3')
    bounds=[1,round(TOTAL/3)+1,round(2*TOTAL/3)+1,TOTAL+1]
    return bounds[chunk-1],bounds[chunk]-1


def run(*args,env=None):
    print('$',' '.join(map(str,args)),flush=True)
    subprocess.run([str(a) for a in args],env=env,check=True)


def ffprobe(path):
    raw=subprocess.check_output(['ffprobe','-v','error','-show_entries',
        'stream=codec_name,codec_type,avg_frame_rate,nb_frames,width,height',
        '-show_entries','format=duration,size','-of','json',str(path)],text=True)
    return json.loads(raw)


def verify_video(path,expected_frames,require_audio=False):
    if not path.exists():raise FileNotFoundError(path)
    dat=ffprobe(path)
    v=next((x for x in dat.get('streams',[]) if x['codec_type']=='video'),None)
    if not v:raise ValueError('No video stream '+str(path))
    fps_str=v.get('avg_frame_rate')
    if not fps_str or '/' not in fps_str:raise ValueError('No exact fps')
    a,b=map(int,fps_str.split('/'))
    if (v.get('codec_name')!='h264' or v.get('width')!=STORY['width'] or
        v.get('height')!=STORY['height'] or a!=FPS*b or
        int(v.get('nb_frames') or 0)!=expected_frames):
        raise ValueError('Incorrect video fields '+json.dumps(v))
    if require_audio and not any(x['codec_type']=='audio' and x['codec_name']=='aac' for x in dat['streams']):
        raise ValueError('Missing AAC voiceover')
    print('VERIFIED',path.name,'frames',expected_frames,'size',path.stat().st_size,flush=True)


def doctor():
    print('V2 CONTENT × KREELUX STYLE',STORY['title'],flush=True)
    print('SHOTS',len(STORY['shots']),'SETS',set(s['set'] for s in STORY['shots']))
    print('FPS',FPS,'FRAMES',TOTAL,'SECONDS',TOTAL/FPS)
    for name in ('blender','ffmpeg','ffprobe','xvfb-run'):
        print(name,shutil.which(name))
    for path in ROOT.joinpath('scripts').glob('*.py'):
        ast.parse(path.read_text(encoding='utf8'))
    assert len(STORY['shots'])==13
    assert all(a<=b for a,b in INTERVALS)
    assert sum(b-a+1 for a,b in INTERVALS)==TOTAL
    assert STORY['source']=='in-this-town-kit-v2.zip / stories/ep03.json first 13 shots only'
    print('DOCTOR OK: project syntax + 13 V2 shots + deterministic 285-frame timeline')


def blender_command(mode,out,chunk=1,start=1,end=24):
    blender=shutil.which('blender')
    if not blender:raise RuntimeError('Blender not installed')
    options=[blender,'--background','--factory-startup','--threads','2',
             '--python',ROOT/'scripts'/'scene_kreelux.py','--','--mode',mode,
             '--chunk',str(chunk),'--start',str(start),'--end',str(end),'--output',out]
    # EEVEE headless can require a virtual X display and CPU Mesa.
    if shutil.which('xvfb-run'):
        options=['xvfb-run','-a','-s','-screen 0 1280x2048x24',*options]
    env=dict(os.environ)
    env['LIBGL_ALWAYS_SOFTWARE']='1'
    env['MESA_GL_VERSION_OVERRIDE']='4.3'
    env['MESA_GLSL_VERSION_OVERRIDE']='430'
    run(*options,env=env)


def make_sheets():
    from PIL import Image,ImageDraw,ImageFont,ImageStat
    stills=OUT/'qa_stills'
    pathlist=sorted(stills.glob('SH*_*.png'))
    if len(pathlist)!=39:raise RuntimeError('Expected 3 QA stills × 13 original V2 shots, got '+str(len(pathlist)))
    try:fnt=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
    except OSError:fnt=ImageFont.load_default()
    for file in pathlist:
        with Image.open(file) as image:
            if image.size!=(270,480):raise RuntimeError('Incorrect QA preview size '+str(file))
            if max(ImageStat.Stat(image.convert('RGB')).stddev)<5.5:raise RuntimeError('Blank/near-blank camera '+str(file))
    # Three moments for each shot; contact sheets of 6–8 shots each.
    for page, indices in enumerate((range(1,8),range(8,14)),start=1):
        w,h=3*270, len(indices)*520
        sheet=Image.new('RGB',(w,h),(22,26,37))
        d=ImageDraw.Draw(sheet)
        for row,shot in enumerate(indices):
            for col,label in enumerate(('start','mid','end')):
                f=stills/('SH%02d_%s.png'%(shot,label))
                with Image.open(f) as im:
                    sheet.paste(im.convert('RGB'),(col*270,row*520+36))
                d.text((col*270+8,row*520+8),'SH%02d %s'%(shot,label),font=fnt,fill=(245,239,210))
            d.line((0,row*520+516,w,row*520+516),fill=(93,97,115),width=2)
        dest=OUT/('contact_sheet_%02d.jpg'%page)
        sheet.save(dest,quality=91)
        print('CONTACT SHEET',dest,flush=True)


def qa():
    doctor()
    OUT.mkdir(exist_ok=True)
    folder=OUT/'qa_stills';folder.mkdir(exist_ok=True)
    blender_command('stills',folder)
    make_sheets()
    print('QA READY: 39 real Blender EEVEE stills, 2 human-readable contact sheets')


def smoke():
    OUT.mkdir(exist_ok=True)
    folder=OUT/'smoke_frames';folder.mkdir(exist_ok=True)
    blender_command('smoke',folder,start=1,end=24)
    frames=list(folder.glob('f_*.png'))
    if len(frames)!=24:raise RuntimeError('Smoke requires 24 genuine Blender frames')
    video=OUT/'kreelux_smoke_1s.mp4'
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-framerate',FPS,
        '-start_number','1','-i',folder/'f_%04d.png','-frames:v','24',
        '-c:v','libx264','-crf','19','-preset','veryfast','-pix_fmt','yuv420p',video)
    # smoke is 270x480 intentionally; do not run 1080x1920 verifier
    print('SMOKE PREVIEW',video)


def render(chunk):
    a,b=clip_range(chunk)
    OUT.mkdir(exist_ok=True)
    frames=OUT/('frames_part_%02d'%chunk)
    frames.mkdir(exist_ok=True)
    blender_command('chunk',frames,chunk=chunk)
    count=b-a+1
    for fr in range(a,b+1):
        p=frames/('f_%04d.png'%fr)
        if not p.is_file() or p.stat().st_size<4096:
            raise RuntimeError('Missing Blender full-quality production frame '+str(p))
    output=OUT/('part_%02d.mp4'%chunk)
    run('ffmpeg','-hide_banner','-loglevel','error','-y',
        '-framerate',FPS,'-start_number',a,'-i',frames/'f_%04d.png',
        '-frames:v',count,'-c:v','libx264','-crf','16','-preset','veryfast',
        '-pix_fmt','yuv420p','-movflags','+faststart',output)
    verify_video(output,count)
    print('PART READY',chunk,a,b)


def ass_time(sec):
    tick=max(0,int(round(sec*100)))
    h,tick=divmod(tick,360000);m,tick=divmod(tick,6000);s,c=divmod(tick,100)
    return f'{h}:{m:02}:{s:02}.{c:02}'


def srt_time(sec):
    t=max(0,int(round(sec*1000)))
    h,t=divmod(t,3600000);m,t=divmod(t,60000);s,ms=divmod(t,1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'


def make_captions():
    path=OUT/'narration_words.json'
    if not path.exists():raise RuntimeError('Need genuine Edge TTS word cues before assembly')
    words=json.loads(path.read_text(encoding='utf8'))
    if not words or not all(x.get('script_exact') for x in words):raise RuntimeError('Missing V2 exact words')
    duration=TOTAL/FPS
    for w in words:
        if not (0<=w['start']<w['end']<=duration+.02):raise RuntimeError('Word outside video '+str(w))
    header='''[Script Info]
Title: IN THIS TOWN Kreelux-style V2 Test
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
ScaledBorderAndShadow: yes
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Word,Noto Sans,94,&H0029DFFF,&H00FFFFFF,&H000B1425,&H770B1425,-1,0,0,0,100,100,0,0,1,5,2,2,35,35,160,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    srt=[];ass=[header]
    for i,w in enumerate(words,1):
        txt=w['word'].replace('\\','').replace('{','').replace('}','').replace('\n',' ')
        srt.append(f'{i}\n{srt_time(w["start"])} --> {srt_time(w["end"])}\n{txt}\n')
        ass.append(f'Dialogue: 0,{ass_time(w["start"])},{ass_time(w["end"])},Word,,0,0,0,,{txt}\n')
    (OUT/'vietsub_words.srt').write_text('\n'.join(srt),encoding='utf8')
    (OUT/'vietsub_karaoke.ass').write_text(''.join(ass),encoding='utf8')
    print('CAPTIONS',len(words),'individual synced words')


def assemble():
    OUT.mkdir(exist_ok=True)
    pieces=[]
    for c in range(1,CHUNKS+1):
        p=OUT/('part_%02d.mp4'%c)
        a,b=clip_range(c)
        verify_video(p,b-a+1)
        pieces.append(p.resolve())
    joined=OUT/'picture_only.mp4'
    manifest=OUT/'concat.txt'
    manifest.write_text(''.join("file '"+str(x).replace("'","'\\''")+"'\n" for x in pieces),encoding='utf8')
    run('ffmpeg','-hide_banner','-loglevel','error','-y',
        '-f','concat','-safe','0','-i',manifest,'-c','copy',joined)
    verify_video(joined,TOTAL)
    voice=OUT/'narration_vi.wav'
    if not voice.is_file():raise RuntimeError('Missing real voice narration')
    make_captions()
    final=OUT/'IN_THIS_TOWN_V2_KREELUX_REAL_TEST_11s.mp4'
    # Output directory contains only ASCII, so ASS path is safe for ffmpeg filter.
    filterexpr='ass=filename='+str((OUT/'vietsub_karaoke.ass').resolve())
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-i',joined,'-i',voice,
        '-vf',filterexpr,'-c:v','libx264','-crf','16','-preset','veryfast',
        '-pix_fmt','yuv420p','-c:a','aac','-b:a','160k',
        '-frames:v',TOTAL,'-t',str(TOTAL/FPS),'-movflags','+faststart',final)
    verify_video(final,TOTAL,require_audio=True)
    print('FINAL FULL QUALITY V2 × KREELUX',final,final.stat().st_size,'bytes')


def main():
    parser=argparse.ArgumentParser()
    choices=parser.add_subparsers(dest='action',required=True)
    choices.add_parser('doctor');choices.add_parser('qa');choices.add_parser('smoke')
    r=choices.add_parser('render');r.add_argument('--chunk',type=int,required=True)
    choices.add_parser('assemble')
    args=parser.parse_args()
    if args.action=='doctor':doctor()
    elif args.action=='qa':qa()
    elif args.action=='smoke':smoke()
    elif args.action=='render':render(args.chunk)
    elif args.action=='assemble':assemble()

if __name__=='__main__':main()
