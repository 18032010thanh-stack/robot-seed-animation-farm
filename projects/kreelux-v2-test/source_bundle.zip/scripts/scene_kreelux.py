"""Kreelux-style original blocky 3D scene generator for 13 ORIGINAL V2 story shots.

Only the *style rules* come from kreelux-roblox-animated-shorts-claude-blender.zip.
Only the *story content* comes from in-this-town-kit-v2.zip / ep03 s001..s013.
No V1 project or video files, Roblox catalog items, licensed rigs, internet assets.

Blender >= 4.2, headless; 13 FK pose bones, unique camera per shot, marker cuts,
procedural street/park/classroom, character key/fill/rim lights, warm AgX,
original model surfaces; PNG frame checkpointing and preview stills.
"""
import argparse
import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[1]
STORY=json.loads((ROOT/'story'/'v2_ep03_kreelux_short.json').read_text(encoding='utf8'))
FPS=STORY['fps']
SHOTS=STORY['shots']
FULL_WIDTH, FULL_HEIGHT=STORY['width'], STORY['height']
TOTAL=STORY['frames']
SCENE_OFFSETS=[80.0*i for i in range(len(SHOTS))]
M={}
RIG_BONES=['Master','Torso','Head','UpArm.L','LowArm.L','UpArm.R','LowArm.R',
           'UpLeg.L','LowLeg.L','UpLeg.R','LowLeg.R','Foot.L','Foot.R']


def clip_intervals():
    running=0.0
    out=[]
    for i,s in enumerate(SHOTS):
        a=round(running*FPS)+1
        running+=float(s['dur'])
        b=round(running*FPS)
        out.append((a,b))
    assert out[0][0]==1 and out[-1][1]==TOTAL
    assert sum(b-a+1 for a,b in out)==TOTAL
    assert all(a<=b for a,b in out)
    return out

INTERVALS=clip_intervals()


def mat(name,rgba,metal=0.0,rough=.56,emit=0.0):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*rgba[:3],1)
    m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value=(*rgba[:3],1)
    bs.inputs['Metallic'].default_value=metal
    bs.inputs['Roughness'].default_value=rough
    if emit:
        for k in ('Emission Color','Emission'):
            if k in bs.inputs:
                bs.inputs[k].default_value=(*rgba[:3],1)
                break
        if 'Emission Strength' in bs.inputs: bs.inputs['Emission Strength'].default_value=emit
    return m


def materials():
    global M
    M={
      'ground':mat('warm cream sandstone',(.60,.57,.49)),
      'pavement':mat('honey stone tiles',(.78,.64,.45)),
      'street':mat('slate blue road',(.31,.39,.47)),
      'grass':mat('vivid stylized meadow',(.25,.48,.28)),
      'leaf':mat('mint leaf',(.35,.64,.37)),
      'leaf2':mat('forest leaf',(.14,.44,.27)),
      'tree':mat('warm cedar tree',(.43,.27,.19)),
      'house':mat('peach stucco',(.89,.61,.45)),
      'house2':mat('cream stucco',(.89,.81,.64)),
      'house3':mat('muted teal facade',(.40,.66,.68)),
      'roof':mat('terracotta roof',(.61,.32,.26)),
      'navy':mat('deep blue frame',(.10,.18,.32)),
      'wood':mat('golden natural wood',(.55,.35,.21)),
      'desk':mat('classroom blonde wood',(.81,.56,.33)),
      'chalk':mat('chalkboard forest green',(.10,.35,.29)),
      'white':mat('warm white',(.94,.91,.83)),
      'window':mat('warm gold windows',(.96,.75,.39),emit=.42),
      'black':mat('warm black pupils',(.04,.05,.07),rough=.18),
      'eyes':mat('off white eyes',(1.0,.97,.87),rough=.2),
      'skin':mat('tan skin',(.87,.61,.44)),
      'skin2':mat('golden skin',(.88,.69,.55)),
      'hero':mat('coral red jacket',(.88,.31,.27)),
      'bin':mat('turquoise tee',(.24,.64,.73)),
      'teacher':mat('teacher violet cardigan',(.54,.36,.69)),
      'trousers':mat('deep denim blue',(.19,.31,.48)),
      'shoes':mat('charcoal sneakers',(.12,.14,.20)),
      'hair':mat('chocolate hair',(.16,.085,.063)),
      'hair2':mat('ginger hair',(.59,.27,.13)),
      'glow':mat('floating magic numbers cyan',(.32,.92,1.0),emit=2.6),
      'glow2':mat('floating magic numbers amber',(1.0,.68,.20),emit=2.0),
      'sun':mat('warm sun',(.98,.83,.49),emit=2.0),
      'pink':mat('peach cheeks',(.93,.43,.40)),
      'gold':mat('gold metal',(.95,.70,.30),metal=.5,rough=.36),
    }


def cube(name,loc,scale,material,bevel=.07):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.object
    o.name=name
    o.scale=scale
    o.data.materials.append(material)
    if bevel:
        mod=o.modifiers.new('Friendly softened edges','BEVEL')
        mod.width=bevel
        mod.segments=2
        if hasattr(mod,'affect'): mod.affect='EDGES'  # Blender-version-safe
        o.modifiers.new('Bevel normals','WEIGHTED_NORMAL')
    return o


def sphere(name,loc,scale,material,segments=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=8,location=loc)
    o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material)
    return o


def cyl(name,loc,scale,material,vertices=12):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=1,depth=1,location=loc)
    o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material)
    return o


def cone(name,loc,scale,material,vertices=8):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices,radius1=1,radius2=0,depth=1,location=loc)
    o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material)
    return o


def text3d(name,body,loc,material,size=.3):
    curve=bpy.data.curves.new(name,'FONT')
    curve.body=str(body)
    curve.size=size
    curve.align_x='CENTER'
    curve.extrude=.011
    curve.bevel_depth=.004
    o=bpy.data.objects.new(name,curve)
    bpy.context.collection.objects.link(o)
    o.location=loc
    # Blender text normals +Z -> global +Y (viewer side)
    o.rotation_euler[0]=math.pi/2
    o.data.materials.append(material)
    return o


def weighted(o,rig,bone):
    """Rigid one-bone weights, so every visual cube follows the actual Blender FK rig."""
    vg=o.vertex_groups.new(name=bone)
    vg.add(list(range(len(o.data.vertices))),1.0,'REPLACE')
    mod=o.modifiers.new('13-bone FK Armature','ARMATURE');mod.object=rig
    return o


def make_rig(name,origin,shirt,skin,hair,body_scale=1.0):
    """Exactly 13 actual FK pose bones; +Y-facing original block character."""
    arm=bpy.data.armatures.new(name+' 13FK')
    rig=bpy.data.objects.new(name+' RIG',arm)
    bpy.context.collection.objects.link(rig)
    rig.location=origin
    bpy.ops.object.select_all(action='DESELECT')
    rig.select_set(True)
    bpy.context.view_layer.objects.active=rig
    bpy.ops.object.mode_set(mode='EDIT')
    edits=arm.edit_bones
    def bone(n,h,t,parent=None):
        e=edits.new(n)
        e.head=h;e.tail=t
        if parent:e.parent=edits[parent]
        return e
    bone('Master',(0,0,.10),(0,0,.30))
    bone('Torso',(0,0,.35),(0,0,1.49),'Master')
    bone('Head',(0,0,1.49),(0,0,2.36),'Torso')
    for s,n in [(-1,'R'),(1,'L')]:
        bone('UpArm.'+n,(s*.48,0,1.46),(s*.61,0,1.02),'Torso')
        bone('LowArm.'+n,(s*.61,0,1.02),(s*.68,0,.73),'UpArm.'+n)
        bone('UpLeg.'+n,(s*.23,0,.76),(s*.23,0,.40),'Master')
        bone('LowLeg.'+n,(s*.23,0,.40),(s*.23,0,.16),'UpLeg.'+n)
        bone('Foot.'+n,(s*.23,0,.16),(s*.23,.26,.12),'LowLeg.'+n)
    bpy.ops.object.mode_set(mode='OBJECT')
    for pb in rig.pose.bones:pb.rotation_mode='XYZ'
    base=Vector(origin)
    def part(n,loc,sz,m,bone_name,bev=.025):
        pos=base+Vector(loc)
        o=cube(name+' '+n,tuple(pos),sz,m,bevel=bev)
        weighted(o,rig,bone_name)
        return o
    part('torso',(0,0,1.18),(.82,.48,.82),shirt,'Torso',.11)
    part('collar',(0,.255,1.49),(.50,.08,.14),M['white'],'Torso',.025)
    part('neck',(0,0,1.62),(.23,.28,.23),skin,'Head',.02)
    part('head',(0,0,1.99),(.68,.68,.67),skin,'Head',.12)
    part('hairtop',(0,-.045,2.37),(.72,.72,.18),hair,'Head',.065)
    part('hairfringe',(0,.335,2.29),(.73,.10,.16),hair,'Head',.04)
    # Eyes + brows + mouth clearly seen from the +Y front camera
    for side in (-1,1):
        ex=side*.155
        part('eyewhite'+str(side),(ex,.348,2.065),(.15,.041,.14),M['eyes'],'Head',.035)
        part('pupil'+str(side),(ex,.391,2.056),(.072,.024,.080),M['black'],'Head',.016)
        part('brow'+str(side),(ex,.374,2.205),(.19,.037,.030),hair,'Head',.012)
        part('cheek'+str(side),(side*.246,.343,1.94),(.080,.012,.05),M['pink'],'Head',.018)
    part('smile',(0,.355,1.889),(.21,.024,.038),M['hair'],'Head',.011)
    for side,n in [(-1,'R'),(1,'L')]:
        part('upperarm'+n,(side*.60,0,1.245),(.25,.30,.46),shirt,'UpArm.'+n,.05)
        part('lowerarm'+n,(side*.66,.01,.88),(.22,.28,.28),skin,'LowArm.'+n,.05)
        part('upperleg'+n,(side*.23,0,.59),(.29,.41,.40),M['trousers'],'UpLeg.'+n,.045)
        part('lowerleg'+n,(side*.23,0,.28),(.28,.40,.36),M['trousers'],'LowLeg.'+n,.035)
        part('shoe'+n,(side*.23,.13,.09),(.33,.53,.16),M['shoes'],'Foot.'+n,.035)
    if body_scale!=1:
        rig.scale=(body_scale,body_scale,body_scale)
    return rig


def key_all_13(rig,frame,phase,character,action):
    """Key all 13 FK controls at each pose; no pose on the next-shot cut frame."""
    for idx,n in enumerate(RIG_BONES):
        pb=rig.pose.bones[n]
        p=phase*2*math.pi
        swing=math.sin(p+idx*.28)
        pb.rotation_euler=(0,0,0)
        if n=='Master':pb.rotation_euler[1]=.016*math.sin(p)
        if n=='Torso':pb.rotation_euler[0]=.024*math.sin(p)
        if n=='Head':
            pb.rotation_euler[0]=.04*math.sin(p+1)
            pb.rotation_euler[2]=.08*math.sin(p*.65)
        if n.startswith('UpArm.'):
            side=1 if n.endswith('L') else -1
            pb.rotation_euler[0]=.14*swing
            pb.rotation_euler[2]=(.12*side + (.20*side if action in ('surprised','talking') else 0))
        if n.startswith('LowArm.'):
            pb.rotation_euler[0]=-.11+.07*swing
        if n.startswith('UpLeg.'):
            pb.rotation_euler[0]=.035*swing
        if n.startswith('LowLeg.'):
            pb.rotation_euler[0]=-.045*math.sin(p+.9)
        if n.startswith('Foot.'):
            pb.rotation_euler[0]=.016*math.sin(p+1.5)
        pb.keyframe_insert('rotation_euler',frame=frame,group=n)
    # Animated idle, no frozen actors; motions end at last frame - 1.
    rig.location.z=.014*math.sin(phase*math.pi*2)
    rig.keyframe_insert('location',frame=frame)


def animate_rig(rig,first,last,action):
    frames=sorted(set([first,first+max(1,(last-first)//3),first+max(2,2*(last-first)//3),max(first,last-1)]))
    for k,fr in enumerate(frames):
        key_all_13(rig,fr,k/3,name_of(rig),action)
    # BEZIER auto clamped prevents limbs overshooting the pose.
    if rig.animation_data and rig.animation_data.action:
        action=rig.animation_data.action
        if hasattr(action,'fcurves'):
            for fc in action.fcurves:
                for pt in fc.keyframe_points:
                    pt.handle_left_type='AUTO_CLAMPED'
                    pt.handle_right_type='AUTO_CLAMPED'


def name_of(rig):return rig.name


def number_above(name,value,world,first,last,gold=False):
    text=text3d(name,'✦ '+str(value),world,M['glow2'] if gold else M['glow'],size=.35)
    z=text.location.z
    for fr,dz in ((first,0),(first+max(1,(last-first)//2),.11),(last,-.025)):
        text.location.z=z+dz
        text.keyframe_insert('location',index=2,frame=fr)
    return text


def build_street(base,seed=0):
    x=base
    cube('Street safe ground',(x,0,-.28),(20,28,.55),M['street'],.045)
    cube('Peach-side sidewalk',(x-4.0,0,-.01),(3.0,25,.12),M['pavement'],.04)
    cube('Cream-side sidewalk',(x+4.0,0,-.01),(3.0,25,.12),M['pavement'],.04)
    for lane in range(8):
        cube('Street center mark',(x,-8+lane*2.2,.02),(.12,.85,.012),M['white'],.009)
    for side in (-1,1):
        for k in range(4):
            bx=x+side*(5.6+(k%2)*.6)
            yy=-10+k*4
            h=4+(k%3)*.65
            cube('Low poly pastel town building',(bx,yy,h/2),(2.4,3.5,h),[M['house'],M['house2'],M['house3']][k%3],.09)
            cube('Bright terracotta roof',(bx,yy,h+.22),(2.6,3.68,.48),M['roof'],.08)
            for j in range(2):
                cube('Window light',(bx-side*1.23,yy-.8+j*1.3,h-1.2),(.05,.72,.74),M['window'],.025)
    for side in (-1,1):
        for j in range(2):
            xx=x+side*2.7;yy=-4+j*6
            cyl('Decorative lantern post',(xx,yy,1.1),(.06,.06,2.15),M['wood'])
            sphere('Lantern warm glow',(xx,yy,2.33),(.22,.22,.22),M['window'])


def build_park(base):
    x=base
    cube('Park grass base',(x,0,-.28),(24,24,.56),M['grass'],.05)
    cube('Park footpath',(x,0,-.01),(4.0,18,.10),M['pavement'],.03)
    for j in range(7):
        xx=x+(-1 if j%2==0 else 1)*(3.2+((j*7)%3)*.42)
        yy=-8+2.6*j
        cyl('Cedar trunk',(xx,yy,1.18),(.18,.19,2.25),M['tree'])
        cone('Cartoon leafy crown',(xx,yy,3.1),(1.18,1.18,2.0),M['leaf'] if j%2 else M['leaf2'])
        sphere('Round crown highlight',(xx,yy,3.42),(.76,.80,.62),M['leaf'])
    for k in range(3):
        x0=x-3.4+k*3.35
        cube('Public wooden bench seat',(x0,-3.2,.62),(1.65,.52,.15),M['desk'])
        for side in (-1,1):
            cube('Bench leg',(x0+side*.63,-3.2,.29),(.11,.13,.6),M['wood'],.02)
        cube('Bench backrest',(x0,-3.52,.98),(1.65,.12,.54),M['wood'])
    for i in range(15):
        a=i*2.399
        r=2.5+.2*i
        sphere('Pastel flower',(x+r*math.cos(a),-2+r*math.sin(a),.12),(.085,.085,.06),M['pink'])


def build_classroom(base):
    x=base
    cube('Classroom warm wood floor',(x,0,-.24),(16,15,.48),M['desk'],.05)
    cube('Classroom back wall',(x,-5.2,3.0),(16,.34,6.1),M['house2'],.05)
    cube('Classroom left wall',(x-7.8,0,3.0),(.25,11,6),M['house'],.03)
    cube('Classroom green board',(x,-4.86,3.16),(6.4,.15,2.9),M['chalk'],.055)
    text3d('Vietnamese class title','10 + 20 = 30',(x,-4.66,3.26),M['white'],size=.48)
    cube('Gold board trim',(x,-4.7,1.69),(6.5,.11,.13),M['gold'])
    for j in range(3):
        yy=-1.3+j*2.3
        for side in (-1,1):
            xx=x+side*2.0
            cube('Student desk',(xx,yy,.90),(1.65,.85,.13),M['desk'])
            for dx in (-.62,.62):
                cube('Desk metal legs',(xx+dx,yy,.48),(.10,.09,.80),M['navy'],.012)
            cube('Student chair',(xx,yy+.85,.63),(.90,.60,.18),M['wood'])
    for side in (-1,1):
        xx=x+side*6.0
        cube('Sunlit classroom window',(xx,-4.9,3.48),(2.0,.16,1.75),M['window'],.07)
        cube('Window vertical frame',(xx,-4.78,3.48),(.075,.16,1.79),M['white'],.01)
        cube('Window horizontal frame',(xx,-4.78,3.48),(2.0,.15,.08),M['white'],.01)


def stage_for_shot(i,interval):
    s=SHOTS[i]
    off=SCENE_OFFSETS[i]
    if s['set']=='street':build_street(off)
    elif s['set']=='park':build_park(off)
    elif s['set']=='class':build_classroom(off)
    else:raise RuntimeError('Unexpected V2 set '+s['set'])
    first,last=interval
    rigs=[]
    cast=s['cast']
    for who in cast:
        if who=='Bo':
            loc=(off-.50,0,.0)
            rig=make_rig('SH%02d Bo'%(i+1),loc,M['hero'],M['skin'],M['hair'])
            number_above('SH%02d Bo magic number'%(i+1), '1', (off-.50,.42,2.82),first,last)
        elif who=='Bin':
            loc=(off+1.28,-.12,0)
            rig=make_rig('SH%02d Bin'%(i+1),loc,M['bin'],M['skin2'],M['hair2'],.93)
            number_above('SH%02d Bin magic number'%(i+1),'43',(off+1.28,.47,2.80),first,last,gold=True)
        elif who=='CoGiao':
            loc=(off+1.25,-1.1,0)
            rig=make_rig('SH%02d Teacher'%(i+1),loc,M['teacher'],M['skin2'],M['hair'],1.03)
            number_above('SH%02d Teacher magic number'%(i+1),'200',(off+1.25,-.65,2.9),first,last,gold=True)
        else:
            continue
        animate_rig(rig,first,last,'talking' if s['line'] else 'idle')
        rigs.append(rig)
    # Some original V2 shots are deliberate visual pauses: still set, moving camera/characters.
    if not rigs:raise RuntimeError('V2 shot missing cast '+s['id'])
    return rigs


def create_camera(i,interval):
    off=SCENE_OFFSETS[i]
    s=SHOTS[i]
    anchor=s.get('anchor','')
    # Originals are short, cinematic Roblox-style portrait shots. Keep camera in +Y
    # hemisphere because characters face +Y; avoid the back-of-head problem.
    if anchor.endswith('_W'):scale=7.9; target_z=2.0; cam_x=.2; cam_y=10.1
    elif anchor.endswith('_M'):scale=6.5; target_z=1.85; cam_x=.6; cam_y=8.4
    elif anchor.endswith('_C'):scale=4.3; target_z=1.90; cam_x=-.25;cam_y=7.5
    elif anchor.endswith('_L'):scale=4.65;target_z=1.84;cam_x=.2;cam_y=7.5
    elif anchor.endswith('_TOP'):scale=7.9; target_z=1.8;cam_x=.3;cam_y=10.0
    elif anchor.endswith('_N'):scale=6.1;target_z=1.83;cam_x=.0;cam_y=8.2
    elif anchor.endswith('_SIDE'):scale=7.1;target_z=1.85;cam_x=1.1;cam_y=8.9
    else:scale=6.3;target_z=1.8;cam_x=.1;cam_y=8.8
    bpy.ops.object.camera_add(location=(off+cam_x,cam_y,4.0))
    cam=bpy.context.object
    cam.name='CAM_SH%02d'%(i+1)
    target=Vector((off+cam_x*.12,0,target_z))
    cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO'
    first,last=interval
    for fr,mult in [(first,1.0),(last,.94)]:
        cam.data.ortho_scale=scale*mult
        cam.data.keyframe_insert(data_path='ortho_scale',frame=fr)
    m=bpy.context.scene.timeline_markers.new('CUT_SH%02d %s'%(i+1,s['id']),frame=first)
    m.camera=cam
    return cam


def key_lights():
    # 45 degrees off portrait camera axis. No big sky/look switch across cuts.
    def area(name,loc,power,col,size):
        bpy.ops.object.light_add(type='AREA',location=loc)
        o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size
        o.data.color=col
        o.rotation_euler=(Vector((loc[0],0,1.5))-o.location).to_track_quat('-Z','Y').to_euler()
        return o
    for idx,off in enumerate(SCENE_OFFSETS):
        area('KEY SH%02d'%(idx+1),(off-4.0,4.4,7.4),1250,(1.0,.66,.42),7)
        area('FILL SH%02d'%(idx+1),(off+4.0,4.2,5.5),460,(.72,.86,1.0),7)
        area('RIM SH%02d'%(idx+1),(off+1.9,-4.1,5.4),780,(1.0,.91,.65),5)
    bpy.ops.object.light_add(type='SUN',location=(0,0,8))
    sun=bpy.context.object;sun.name='Golden hour sun';sun.data.energy=2.5
    sun.data.color=(1.0,.64,.36)
    sun.rotation_euler=(math.radians(24),math.radians(-20),math.radians(-25))


def render_settings(preview):
    scene=bpy.context.scene
    scene.render.resolution_x=FULL_WIDTH
    scene.render.resolution_y=FULL_HEIGHT
    scene.render.resolution_percentage=25 if preview else 100
    scene.render.fps=FPS
    scene.render.film_transparent=False
    scene.frame_start=1
    scene.frame_end=TOTAL
    scene.render.image_settings.file_format='PNG'
    scene.render.image_settings.color_mode='RGB'
    scene.render.image_settings.color_depth='8'
    # The original Kreelux guide asks for EEVEE, 2 preview vs 16 final samples.
    available=[a.identifier for a in bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items]
    for candidate in ('BLENDER_EEVEE_NEXT','BLENDER_EEVEE'):
        if candidate in available:
            scene.render.engine=candidate
            break
    else:
        raise RuntimeError('EEVEE unavailable in Blender build: '+str(available))
    if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_render_samples'):
        scene.eevee.taa_render_samples=2 if preview else 16
    if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_samples'):
        scene.eevee.taa_samples=2 if preview else 16
    if hasattr(scene,'eevee') and hasattr(scene.eevee,'use_raytracing'):
        scene.eevee.use_raytracing=not preview
    if hasattr(scene.render,'use_motion_blur'):
        scene.render.use_motion_blur=not preview
    if hasattr(scene.render,'motion_blur_position'):
        try:scene.render.motion_blur_position='START'
        except (TypeError,ValueError):pass
    try:scene.view_settings.view_transform='AgX'
    except Exception:pass
    try:scene.view_settings.look='Medium High Contrast'
    except Exception:pass
    scene.view_settings.exposure=.35
    if bpy.data.worlds:
        scene.world=bpy.data.worlds[0]
    else:
        scene.world=bpy.data.worlds.new('Golden hour outdoors')
    scene.world.use_nodes=True
    bg=scene.world.node_tree.nodes.get('Background')
    bg.inputs['Color'].default_value=(.28,.42,.60,1)
    bg.inputs['Strength'].default_value=.65
    scene.render.image_settings.compression=35
    scene.render.filepath=str(ROOT/'output'/'unused.png')


def build(preview):
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    bpy.context.scene.timeline_markers.clear()
    materials()
    scene=bpy.context.scene
    render_settings(preview)
    cameras=[]
    for i,interval in enumerate(INTERVALS):
        stage_for_shot(i,interval)
        cameras.append(create_camera(i,interval))
    key_lights()
    scene.camera=cameras[0]
    return scene,cameras


def which_shot(frame):
    for i,(a,b) in enumerate(INTERVALS):
        if a<=frame<=b:return i
    raise ValueError('Frame out of bounds '+str(frame))


def frame_render(scene,cameras,fr,path):
    scene.frame_set(fr)
    scene.camera=cameras[which_shot(fr)]
    scene.render.filepath=str(path)
    bpy.ops.render.render(write_still=True)
    if not path.exists() or path.stat().st_size<2048:raise RuntimeError('Blank/missing PNG: '+str(path))


def main():
    raw=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('stills','chunk','smoke'),required=True)
    parser.add_argument('--chunk',type=int,default=1)
    parser.add_argument('--start',type=int,default=1)
    parser.add_argument('--end',type=int,default=24)
    parser.add_argument('--output',required=True)
    args=parser.parse_args(raw)
    random.seed(201103)
    preview=args.mode in ('stills','smoke')
    scene,cameras=build(preview)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if args.mode=='stills':
        planned=[]
        for i,(a,b) in enumerate(INTERVALS):
            for label,fr in (('start',a),('mid',(a+b)//2),('end',b)):
                planned.append((fr,out/('SH%02d_%s.png'%(i+1,label))))
    elif args.mode=='smoke':
        planned=[(k,out/('f_%04d.png'%k)) for k in range(args.start,min(args.end,TOTAL)+1)]
    else:
        chunks=[(1,round(TOTAL/3)),(round(TOTAL/3)+1,round(TOTAL*2/3)),(round(TOTAL*2/3)+1,TOTAL)]
        if not 1<=args.chunk<=len(chunks):raise RuntimeError('Only 3 supported chunks')
        a,b=chunks[args.chunk-1]
        planned=[(k,out/('f_%04d.png'%k)) for k in range(a,b+1)]
    if not preview:
        # Source-friendly .blend for reproducibility/review before long rendering.
        bpy.ops.wm.save_as_mainfile(filepath=str(out/'kreelux_v2_scene.blend'))
    print('STAGED',len(INTERVALS),'original V2 shots;',len(planned),'frames;',
          'resolution',scene.render.resolution_percentage,'pct',flush=True)
    for k,(fr,p) in enumerate(planned):
        if p.exists() and p.stat().st_size>2048:
            continue
        frame_render(scene,cameras,fr,p)
        print('RENDERED',k+1,'/',len(planned),'global frame',fr,p,flush=True)
    print('COMPLETE',len(planned),'frames',flush=True)

if __name__=='__main__':main()
