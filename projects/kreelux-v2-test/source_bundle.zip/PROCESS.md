# PROCESS — production decisions and quality gates

## 2026-11-20 — Initial project setup

1. User asked for a **genuine test video on GitHub Actions**, using only the visual style of the new Kreelux file, preserving V2 story source and not modifying V1.
2. Inspected all 17 text files in `kreelux-roblox-animated-shorts-claude-blender.zip`, and extracted exact V2 ep03 shots s001–s013 from `in-this-town-kit-v2.zip` (11.87 seconds; 285 frames at 24fps). V1 was not consulted.
3. Original geometry only. New 13-bone FK armatures and camera markers per shot, warm key/fill/rim, AgX, no downloaded Roblox/Sketchfab models. Production target 1080×1920 Eevee16 with stills at 25%.
4. QA: 3 stills × 13 shots, 2 contact sheets, real 24-frame smoke video before full render. One second of real motion is a technical smoke test, not a deliverable substitute.
5. Voice and exact word captions built from V2 Vietnamese lines and real TTS timing; no ElevenLabs credential was given; Edge voice is the V2's original setting.
6. Native background Blender render uses `write_still=True` (cannot invoke GUI `INVOKE_DEFAULT` on headless GitHub); PNG output can be resumed from a partially completed job workspace.
7. GitHub job must pass real Blender QA then render 3 independent chunks, FFprobe verification, final audio and one-word captions. Do not render full 155s.

## Pending reviews

- [ ] Actual Blender QA 39 frames visually reviewed: characters in shot, faces toward cameras, no floating/sinking, consistency.
- [ ] End-to-end EEVEE headless GPU availability and outputs tested on GitHub Actions.
- [ ] Real voice service and word timings generated; audible and correctly paced.
- [ ] 3 × 95-frame full-res renders succeed and PNGs count verified.
- [ ] 285-frame MP4 H.264 + AAC + Vietnamese word subtitles built and playable.
- [ ] Final 11.875-second clip reviewed for continuity, expressions, image noise and audio.

Any failed item must be reported plainly; do not claim the final video is ready.
