# In This Town — Episode 03: **V2 story × NEW Kreelux visual style**

A **real Blender 3D production-grade test** of the first 13 original V2 episode-03 shots, not a throwaway mockup and not a full 155-second episode.

| Metric | Value |
|---|---|
| Source of content | Original `in-this-town-kit-v2.zip` → `stories/ep03.json`, shots `s001..s013` |
| Source of *style only* | NEW `kreelux-roblox-animated-shorts-claude-blender.zip` |
| Video duration | 285/24 = **11.875 seconds** |
| Resolution | **1080 × 1920 (9:16)** |
| Render | Blender **EEVEE**, 16 render samples (where Blender version supports setting) |
| QA | **39 real Blender stills**, 3 per shot + 2 contact sheets; 24 real motion frames |
| Animation | Original blocky 3D FK rigs, **13 bones**, custom character clothes/hair/expressions, 13 camera cuts |
| Voice | Vietnamese `vi-VN-NamMinhNeural` via online Edge TTS, original story text + matching word cues |
| Captions | Burned-in one-word yellow Vietnamese subtitles + SRT file |
| Output | 3 chunk MP4 → FFmpeg concat → final CRF16 H.264/AAC |

## GitHub Cloud workflow

Use the isolated development branch `kreelux-v2-test` in `18032010thanh-stack/robot-seed-animation-farm`. It does **not modify main or V1 files**. Code lives only in `projects/kreelux-v2-test/` and the branch-specific GitHub Actions workflows.

- QA workflow generates 39 25%-resolution still frames, contact sheets, a real 1-second moving-camera video and actual narration. **Inspect the contact sheets and voice first.**
- Production workflow renders 3 independent blocks of 95 full-resolution frames and then concatenates with FFmpeg and burns in word-synced subtitles; no entire 155-second render.
- The workflows use `xvfb`/Mesa for headless EEVEE where supported. If not supported, fail honestly rather than silently switching to the previous project's Cycles renderer.
- If Edge TTS or other required downloads fail, the run stops. No unverified substitute media.

## Local commands (Blender, FFmpeg, Python installed)

```bash
python3 -m pip install -r requirements.txt
python3 scripts/pipeline.py doctor
python3 scripts/prepare_audio.py
python3 scripts/pipeline.py qa
python3 scripts/pipeline.py smoke
python3 scripts/pipeline.py render --chunk 1
python3 scripts/pipeline.py render --chunk 2
python3 scripts/pipeline.py render --chunk 3
python3 scripts/pipeline.py assemble
```

**Rights:** The new Kreelux ZIP is only prompt templates and explicitly excludes source Roblox rigs, clothes and proprietary meshes. No unlicensed Roblox/Sketchfab assets or V1 elements are used. No music. Review Edge TTS rights for commercial publishing.
