# Audit — **V2 story × Kreelux NEW visual style**

The original user instruction is to use **only the NEW ZIP's style**. The package `kreelux-roblox-animated-shorts-claude-blender.zip` contains **17 text-only files**, not Blender rigs, clothing or scenes. All 17 were read; no archived V1 film/code/audio is used. **Story** is the first 13 original shots of V2 episode `stories/ep03.json` from the separate `in-this-town-kit-v2.zip` (no code from that kit reused). Exact lines, cast, sets, IDs and original nominal durations preserved.

## New style package: mapping all 17 files

| File in Kreelux ZIP | Treatment in this production sample |
|---|---|
| `README.txt` | Acknowledged that rigs, face PNGs, Roblox items, Sketchfab models are intentionally absent; not claimed available |
| `prompts/01-find-the-formula.txt` | No user-supplied ten top-performing transcripts; cannot truthfully extract empirical formula. Do not invent one |
| `prompts/02-write-the-script.txt` | Script is original **V2 ep03**, kept as requested; not rewritten into an unrelated story. Kid-safe and short, Vietnamese narration |
| `prompts/03-word-timings.txt` | Real TTS WordBoundary data with difflib alignment to original script exact spellings in `prepare_audio.py`; no fake timestamps. Faster-whisper alternative not used because Edge provides word timestamps directly |
| `prompts/04-project-rules.txt` | Rebuild from Python scripts, `PROCESS.md`, `CREDITS.md`, saved `.blend`, low-res still reviews. In headless Blender, `INVOKE_DEFAULT` is not usable; use synchronous `bpy.ops.render.render(write_still=True)` |
| `prompts/05-dress-the-characters.txt` | Brand catalog not bundled/licensed, and no credentials supplied. Use original geometric clothing and hairstyles; no item downloaded or falsely called official |
| `prompts/05-rig-facts.txt` | New 13-FK-bone Blender armatures; characters face **+Y**, cameras in +Y hemisphere, pose all 13 bones. This is an original rig, not the proprietary Starter Rig |
| `prompts/06-build-the-world.txt` | Original procedural street, park and classroom sets; zero external assets = zero Sketchfab licensing/credit problems; render three QA stills/shot |
| `prompts/08-animate-shots.txt` | 13 individual cameras with timeline markers, 13 FK poses, breathing/sway, no key at cut frame, correct ground height, markers and deterministic cuts, portrait framing |
| `prompts/10-qa-round.txt` | Root-cause feedback captured in `PROCESS.md`, inspect real contact sheets before adopting a new look |
| `templates/shot-list-template.csv` | Project shot-list auto derived from exact V2 shot IDs/lines/sets; cut frame boundaries from original V2 durations |
| `templates/story-formula-10-beats.txt` | The 10-beat narrative is for a ~2-min full short; a 11.875-s V2 test cannot encompass the full 10 beats. Only visual/editing style sampled; do not pretend otherwise |
| `templates/elevenlabs-settings.txt` | ElevenLabs v3 voice/model requires user credentials and licensing. For the Vietnamese test, use V2's `vi-VN-NamMinhNeural` via online TTS; fail if service unavailable, do not fabricate narration |
| `templates/render-settings.txt` | Warm key/fill/rim, AgX +0.35, portrait 1080×1920 @ 24fps, Eevee preview25% and production16 samples, PNG frames H.264 CRF16, no downloadable HDRI (not bundled). Original sky shader used |
| `checklists/qa-checklist.txt` | Render exactly 3 frames per shot (39 total) and 2 contact sheets, automatic blank frames checks; human visual review still needed |
| `checklists/final-render-checklist.txt` | Every frame separate PNG for partial recovery; 3 chunks in independent Actions jobs; validate output with FFprobe, inspect final MP4 and credits |
| `commands/commands.txt` | FFmpeg for frames → H.264, 24fps, optional audio/subtitles; no legacy video dependencies |

## Provenance and permissions

- Story source: `in-this-town-kit-v2.zip` → `in-this-town-kit/stories/ep03.json` → shots `s001` through `s013` **ONLY**. The story JSON records the SHA-256 of this source file; stage script uses only the saved selected-shot JSON.
- Style source: the new Kreelux ZIP. None of its text/rigs/assets are included in the public GitHub branch; only this independently written style interpretation.
- Assets: all 3D geometry, hair, clothing, rooms, town, parks, magic numbers are **procedural new meshes**. No Roblox, Sketchfab or third-party artwork is redistributed.
- Audio: Vietnamese TTS requires network; no cloning or licensed audio. Final voice should be reviewed before publication.
- The 155-second episode is **not** being produced. This is a serious 11.875-second 285-frame **production test**, with 39 QA stills, original 13 cameras and 13-bone animation.

## Important limitations

- No actual Roblox Starter Rig or official catalog items: cannot reproduce their technical UV/attachment rig details without authorized assets. We intentionally build an original blocky equivalent.
- Blender 5.x Eevee on headless GitHub runner may depend on Mesa/Xvfb. The workflow performs a real smoke test and fails honestly rather than substituting unrelated frames.
- For online TTS, network/download errors halt the run, per the new style package's rule. No fake audio or substitute model is used.
- A successful MP4 is claimed **only after** a 285-frame, full-res H.264 + AAC + caption result is verified and downloaded.
