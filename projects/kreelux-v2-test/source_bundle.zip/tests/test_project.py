"""Offline integrity tests: content V2, style NEW, no V1 dependencies."""
import ast
import hashlib
import json
import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
STORY=json.loads((ROOT/'story'/'v2_ep03_kreelux_short.json').read_text(encoding='utf8'))

class TestV2KreeluxStyle(unittest.TestCase):
    def test_13_unchanged_v2_shot_identifiers(self):
        self.assertEqual([x['id'] for x in STORY['shots']],['s%03d'%i for i in range(1,14)])
        self.assertEqual(STORY['source'],'in-this-town-kit-v2.zip / stories/ep03.json first 13 shots only')

    def test_runtime_and_camera_count(self):
        self.assertEqual(STORY['fps'],24)
        self.assertEqual(STORY['frames'],285)
        self.assertEqual(STORY['width'],1080)
        self.assertEqual(STORY['height'],1920)
        self.assertEqual(len(STORY['shots']),13)
        self.assertEqual(set(x['set'] for x in STORY['shots']),{'street','park','class'})

    def test_3_complete_chunks(self):
        import sys
        sys.path.insert(0,str(ROOT/'scripts'))
        from pipeline import clip_range,INTERVALS
        self.assertEqual([clip_range(i) for i in (1,2,3)],[(1,95),(96,190),(191,285)])
        self.assertEqual(sum(b-a+1 for a,b in INTERVALS),285)

    def test_scripts_parse(self):
        for p in (ROOT/'scripts').glob('*.py'):
            ast.parse(p.read_text(encoding='utf8'),filename=str(p))

    def test_no_legacy_dependencies(self):
        for p in (ROOT/'scripts').glob('*.py'):
            s=p.read_text(encoding='utf8')
            for bad in ('scene_robot_seed','rt_render.py','last_one_awake.json','make_animatic.py'):
                self.assertNotIn(bad,s,str(p))

if __name__=='__main__':unittest.main(verbosity=2)
